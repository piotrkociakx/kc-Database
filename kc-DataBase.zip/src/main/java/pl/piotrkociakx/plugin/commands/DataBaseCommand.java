package pl.piotrkociakx.plugin.commands;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.command.defaults.BukkitCommand;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import pl.piotrkociakx.api.database.mysql.MySQLDataBase;
import pl.piotrkociakx.api.database.mysql.keepalive.KeppAlive;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

public class DataBaseCommand extends BukkitCommand {

    public DataBaseCommand(String name) {
        super(name);
    }

    @Override
    public boolean execute(CommandSender commandSender, String s, String[] strings) {
        if (commandSender instanceof Player) {
            Player player = (Player) commandSender;
            player.openInventory(database(player));
        }
        return true;
    }

    public Inventory database(Player player) {
        Inventory inventory = Bukkit.createInventory(player, 54, "Baza Danych");

        List<Connection> available = MySQLDataBase.availableConnections;
        List<Connection> used = MySQLDataBase.usedConnections;

        Material availableMaterial = Material.SULPHUR;
        Material usedMaterial = Material.GLOWSTONE_DUST;

        int[] connectionSlots = new int[] {2, 3, 4, 5, 6, 11, 12, 13, 14, 15};

        int index = 0;
        int connint = 1;

        for (Connection conn : available) {
            if (index >= connectionSlots.length || index >= MySQLDataBase.maxPoolSize) break;

            ItemStack stack = new ItemStack(availableMaterial, connint);
            ItemMeta meta = stack.getItemMeta();
            meta.setDisplayName("§aPołączenie");
            List<String> lore = new ArrayList<>();
            lore.add("§aStatus: §2Dostępny");
            meta.setLore(lore);
            stack.setItemMeta(meta);

            inventory.setItem(connectionSlots[index], stack);
            connint++;
            index++;
        }

        for (Connection conn : used) {
            if (index >= connectionSlots.length || index >= MySQLDataBase.maxPoolSize) break;

            ItemStack stack = new ItemStack(usedMaterial, connint);
            ItemMeta meta = stack.getItemMeta();
            meta.setDisplayName("§aPołączenie");
            List<String> lore = new ArrayList<>();
            lore.add("§aStatus: §bUzywane");
            meta.setLore(lore);
            meta.addEnchant(Enchantment.DURABILITY, 10, true);
            stack.setItemMeta(meta);
            inventory.setItem(connectionSlots[index], stack);
            connint++;
            index++;
        }

        ItemStack dye = new ItemStack(Material.INK_SACK, 1, (short) 12);
        ItemMeta meta = dye.getItemMeta();
        List<String> lore = new ArrayList<>();
        lore.add("Ostatni ping: "+ KeppAlive.lastPing.toString());

        return inventory;
    }
}
