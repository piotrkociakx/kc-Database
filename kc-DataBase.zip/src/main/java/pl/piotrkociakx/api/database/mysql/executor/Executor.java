package pl.piotrkociakx.api.database.mysql.executor;

import org.bukkit.scheduler.BukkitRunnable;
import pl.piotrkociakx.api.database.mysql.MySQLDataBase;
import pl.piotrkociakx.api.database.mysql.taskHandler.TaskHandler;
import pl.piotrkociakx.api.type.TaskType;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Comparator;
import java.util.stream.Collectors;
import java.util.concurrent.CompletableFuture;

public class Executor extends BukkitRunnable {

    @Override
    public void run() {
        List<TaskHandler> sortedTasks = MySQLDataBase.tasks.stream()
                .sorted(Comparator.comparing(task -> task.getType() == TaskType.execute ? 0 : 1))
                .collect(Collectors.toList());

        sortedTasks.forEach((task) -> {
            if (task.getType() == TaskType.update) {
                CompletableFuture.runAsync(() -> executeTask(task));
                sortedTasks.remove(task);
            } else {
                executeTask(task);
                sortedTasks.remove(task);
            }
        });
    }

    private void executeTask(TaskHandler task) {
        Connection connection = MySQLDataBase.getConnection();
        if (connection == null) {
            return;
        }

        try (PreparedStatement statement = connection.prepareStatement(task.getQuery())) {
            if (task.getQuery().trim().toUpperCase().startsWith("SELECT")) {
                try (ResultSet resultSet = statement.executeQuery()) {
                    task.setResultSet(resultSet);
                }
            } else {
                statement.executeUpdate();
                task.setResultSet(null);
            }
        } catch (SQLException e) {
            System.out.print("Can not execute: " + e.getMessage() + "\n\n Query: " + task.getQuery() + "\n Location: " + e.getLocalizedMessage());
            task.setResultSet(null);
        }
    }
}
