package pl.piotrkociakx.api.database.flat;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import pl.piotrkociakx.api.DataBase;

import java.io.File;
import java.io.IOException;

public class FlatDataBase {

    public static FileConfiguration getData;

    private final JavaPlugin plugin;
    private final File file;
    private final FileConfiguration config;

    public FlatDataBase(File file) {
        this.plugin = DataBase.getPlugin();
        this.file = file;
        if (!this.file.exists()) {
            plugin.saveResource(String.valueOf(file), false);
        }
        this.config = YamlConfiguration.loadConfiguration(this.file);
        getData = this.config;
    }

    public void load() {
        if (config == null) {
            System.out.println("Config file not found or failed to load.");
            plugin.getPluginLoader().disablePlugin(plugin);
            return;
        }
    }

    public void save() {
        try {
            config.save(file);
        } catch (IOException e) {
            System.out.print("Can not save data: " + e.getMessage());
        }
    }
}
