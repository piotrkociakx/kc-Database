package pl.piotrkociakx.api.database.mysql.taskHandler;

import lombok.Getter;
import lombok.Setter;
import pl.piotrkociakx.api.type.TaskType;

import java.sql.ResultSet;

@Getter
public class TaskHandler {
    private final TaskType type;
    private final String query;
    @Setter
    private ResultSet resultSet;

    public TaskHandler(TaskType type, String query) {
        this.type = type;
        this.query = query;
    }
}
