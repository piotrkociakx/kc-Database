package pl.piotrkociakx.api.database.settings;

import lombok.Getter;
import org.bukkit.plugin.java.JavaPlugin;
import pl.piotrkociakx.api.DataBase;

import java.io.File;

@Getter
public class DataSettings {
    private final String host;
    private final int port;
    private final String username;
    private final String password;
    private final String database;
    private final int maxpoolsize;
    private final JavaPlugin plugin;
    private final File flatfile;

    public DataSettings(String host, int port, String username, String password, String database, int maxPoolSize, File flatFile) {
        this.flatfile = flatFile;
        this.host = host;
        if(port == 0) {
            this.port = 3306;
        } else {
            this.port = port;
        }
        this.username = username;
        this.password = password;
        this.database = database;
        if(maxPoolSize == 0) {
            this.maxpoolsize = 1;
        } else {
            this.maxpoolsize = maxPoolSize;
        }
        this.plugin = DataBase.getPlugin();
    }
}
