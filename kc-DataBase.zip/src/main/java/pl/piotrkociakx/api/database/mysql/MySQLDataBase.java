package pl.piotrkociakx.api.database.mysql;

import pl.piotrkociakx.api.database.mysql.executor.Executor;
import pl.piotrkociakx.api.database.mysql.keepalive.KeppAlive;
import pl.piotrkociakx.api.database.settings.DataSettings;
import pl.piotrkociakx.api.database.mysql.taskHandler.TaskHandler;
import pl.piotrkociakx.api.type.TaskType;

import java.sql.*;
import java.util.Date;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class MySQLDataBase {

    private final DataSettings settings;
    public static int maxPoolSize;
    public static List<Connection> availableConnections;
    public static List<Connection> usedConnections;
    public static List<TaskHandler> tasks;
    public static Date getLastQuery;

    public MySQLDataBase(DataSettings settings) {
        this.settings = settings;
        maxPoolSize = settings.getMaxpoolsize();
        availableConnections = new ArrayList<>();
        for (int i = 0; i < maxPoolSize; i++) {
            createConnection();
        }
        usedConnections = new ArrayList<>();
        tasks = new ArrayList<>();

        new Executor().runTaskTimer(settings.getPlugin(), 0L, 1L);
        new KeppAlive().runTaskTimer(settings.getPlugin(), 100L, 18000L);



    }

    public static Connection getConnection() {
        getLastQuery = new Date();
        if ((availableConnections == null || availableConnections.isEmpty())) {
            return null;
        } else {
            usedConnections.add(availableConnections.remove(new Random().nextInt(availableConnections.size())));
            return usedConnections.get(usedConnections.size() - 1);
        }
    }

    public static void releaseConnection(Connection connection) {
        if (connection != null && usedConnections.contains(connection)) {
            usedConnections.remove(connection);
            availableConnections.add(connection);
        }
    }


    public void createConnection() {
        try {
            Connection connection = DriverManager.getConnection(
                    "jdbc:mysql://{ip}:{port}/{database}"
                            .replace("{ip}", settings.getHost())
                            .replace("{port}", String.valueOf(settings.getPort()))
                            .replace("{database}", settings.getDatabase())
                    , settings.getUsername()
                    , settings.getPassword()
            );

        } catch (SQLException e) {
            System.out.print("Can not create an MySQL connection: " + e.getMessage());
            settings.getPlugin().getPluginLoader().disablePlugin(settings.getPlugin());
        }
    }

    public static void executeUpdate(String query) {
        tasks.add(new TaskHandler(TaskType.update, query));
    }

    public static ResultSet execute(String query) {
        TaskHandler taskHandler = new TaskHandler(TaskType.execute, query);
        tasks.add(taskHandler);

        while (tasks.get(tasks.indexOf(taskHandler)).getResultSet() == null) {
            try {
                TimeUnit.MILLISECONDS.sleep(25);
            } catch (InterruptedException e) {
                System.out.println("Can't wait to return value: " + e.getMessage());
            }
        }

        return tasks.get(tasks.indexOf(taskHandler)).getResultSet();
    }


    public static void pingDatabase(Connection connection) {
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT 1");

            if (resultSet.next()) {
                resultSet.close();
                statement.close();
            }
        } catch (SQLException ignored) {}
    }
}
