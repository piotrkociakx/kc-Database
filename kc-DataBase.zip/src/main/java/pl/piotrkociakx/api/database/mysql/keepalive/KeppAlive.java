package pl.piotrkociakx.api.database.mysql.keepalive;

import org.bukkit.scheduler.BukkitRunnable;
import pl.piotrkociakx.api.database.mysql.MySQLDataBase;

import java.util.Date;

public class KeppAlive extends BukkitRunnable {

    public static Date lastPing;

    @Override
    public void run() {
        MySQLDataBase.availableConnections.forEach(MySQLDataBase::pingDatabase);
        lastPing = new Date();
    }
}
