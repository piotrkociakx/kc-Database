package pl.piotrkociakx.api.type;

public enum DataType {
    mysql,
    flat
}
