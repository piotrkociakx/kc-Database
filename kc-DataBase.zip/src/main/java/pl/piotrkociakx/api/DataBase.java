package pl.piotrkociakx.api;

import org.bukkit.plugin.java.JavaPlugin;
import pl.piotrkociakx.api.database.flat.FlatDataBase;
import pl.piotrkociakx.api.database.mysql.MySQLDataBase;
import pl.piotrkociakx.api.database.settings.DataSettings;
import pl.piotrkociakx.api.type.DataType;

public class DataBase {
    private static JavaPlugin plugin;
    public static DataType type;

    public static JavaPlugin getPlugin() {
        return plugin;
    }

    public void setPlugin(JavaPlugin pluginInstance) {
        plugin = pluginInstance;
    }

    public void loadDataBase(DataType type, DataSettings settings) {
        DataBase.type = type;
        if(type.equals(DataType.mysql)) {
            System.out.print("Using MySQL...");
            new MySQLDataBase(settings);
        } else {
            System.out.print("Using Flat...");
            new FlatDataBase(settings.getFlatfile());
        }




    }
}
