package pl.piotrkociakx;

public class DataBaseLib {
}
